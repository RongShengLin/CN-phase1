# CN-phase1    
This is for CN phase1
## Compile  
### use "gcc server.c -o server" to compile  
## Run  
### use "./server" to run
### There is a IP and Port Num in third line(it may be Private IP, not Public IP.If it is Private IP, then we can connect to webpage via this IP)
### If IP address is not work well, there is another process run in GCP, and it's IP and Port Num is" 34.81.176.7:7891 "(http://34.81.176.7:7891/)
